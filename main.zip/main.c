#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node
{
    char name[35];
    struct node *next;
} node;
node *head, *temp, *last;

void readTVs();
int menu();
void addTV();
void display();
void addOrder();
void process();
void cancel();
void displayLast();
void updateFile();

int main()
{
    int customerchoice = 0;
    int quit = 0;
    head = NULL;
    temp = NULL;
    last = NULL;
    readTVs();
    customerchoice = menu();
    printf("%d", customerchoice);
    if (quit == 0)
    {
        switch (customerchoice)
        {
            case 1:
                display();
                break;
           // case 2:
               // addTV();
               // break;
            case 2:
                addOrder();
                break;
            case 3:
                process();
                break;
            case 4:
                cancel();
                break;

            case 5:
                displayLast();
                break;
            case 6:
                updateFile();
                break;

            case 7:
                quit = 1;
                break;
            default:
                printf("That was an invalid input Please Try again.");
        }

    }
    return 0;
}

void readTVs()
{
    char name[35];
    FILE *fp;
    fp = fopen("TV.txt", "r");
    if (fp == NULL)
    {
        printf("Wozza!There Was an error while opening this file.\n");
        exit(1); // return or exit from the function
    }

    while (!feof(fp))
    {
        fscanf(fp, "%s", name);
        temp = (node *)malloc(sizeof(node));
        strcpy(temp->name, name);
        temp->next = NULL;
        if (head == NULL)
        {
            head = temp;
            last = temp;
        }
        else
        {
            last->next = temp;
            last = temp;
        }
    }
    fclose(fp);
}

int menu()
{
    int customerchoice;
    printf("\n1.Our Current stock of the TVs\n");
   // printf("2.Add a TV to the current stock\n");
    printf("2.Next Order Information\n");
   // printf("4.All orders requested\n");
   // printf("5.Add an order to the Queue\n");
    printf("3.Start Processing next order\n");
    printf("4.Cancel Previous order\n");
    printf("5.Information about the last order\n");
    printf("6.Update the TV file\n");
    printf("7.Quit The Program\n");
    printf("Please Enter your choice\n");
    scanf("%d", &customerchoice);
    return customerchoice;
}

void addTV()
{
    char name[35];
    printf("Enter The name of the TV");
    scanf("%s", name);
    temp = (node *)malloc(sizeof(node));
    strcpy(temp->name, name);
    temp->next == NULL;
    if (head == NULL)
    {
        head = temp;
        last = temp;
    }
    else
    {
        last->next = temp;
        last = temp;
    }
    printf("The Tv was added successfully Comrade!");
     main();
}

void display()
{
    printf("Stock for TVs\n");
    temp = head;
    if (temp == NULL)
    {
        printf("Empty");
    }
    else
    {
        while (temp != NULL)
        {
            printf("\n%s\n", temp->name);
            temp = temp->next;
        }
    }
    main();
}

void addOrder()
{
    char name[35];
    printf("Please Input the name of the TV");
    scanf("%s", name);
    temp = (node *)malloc(sizeof(node));
    strcpy(temp->name, name);
    if (head == NULL)
    {
        head = temp;
        last = temp;
    }
    else
    {
        last->next = temp;
        last = temp;
    }
    printf("Your Order was Added successfully");
    main();
}

void process()
{
    temp = head;
    if (temp == NULL)
    {
        printf("There was no order to process");
    }
    else
    {
        printf("Processing Order:%s\n", temp->name);
        head = head->next;
        temp = head;
        if (temp == NULL)
        {
            last = NULL;
        }
    }
     main();
}

void cancel()
{
    temp = head;
    if (temp == NULL)
    {
        printf(" There was no order to cancel");
    }
    else
    {
        printf("Cancelling The order: %s\n", temp->name);
        head = head->next;
        temp = head;
        if (temp == NULL)
        {
            last = NULL;
        }
    }
     main();
}

void displayLast()
{
    temp = head;
    if (temp == NULL)
    {
        printf("There is no order to display");
    }
    else
    {
        while (temp != NULL)
        {   
            temp = temp->next;
            if (temp->next == NULL)
            {
                printf("Last Order: %s", temp->name);
            }
        }
        
    }
    
}

void updateFile()
{
    char name[35];
    FILE *fp;
    fp = fopen("TV.txt", "a");
    if (fp == NULL)
    {
        printf("Wozza, There was an error opening this file", "TV.txt");
        main();
        //exit(1);
    }
    temp = head;
    if (temp == NULL)
    {
        printf("There are no TVs to update");
    }
    else
    {
        scanf("%s\n", &name);
        fprintf(fp, "%s\n", name);        
        temp = temp->next;
    }

    fclose(fp);
    main();
}
